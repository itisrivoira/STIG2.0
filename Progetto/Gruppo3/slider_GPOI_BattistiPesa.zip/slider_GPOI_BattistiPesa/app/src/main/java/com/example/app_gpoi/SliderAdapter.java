package com.example.app_gpoi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.viewpager.widget.PagerAdapter;

import org.w3c.dom.Text;

public class SliderAdapter extends PagerAdapter {

    Context context;
    LayoutInflater layoutInflater;

    public SliderAdapter(Context context){
        this.context = context;
    }

    public int[] slide_images = {
        R.mipmap.ic_launcher,
        R.mipmap.ic_launcher_round,
        R.mipmap.ic_launcher
    };

    public String[] slide_titolo = {
        "FACILE",
        "MEDIO",
        "DIFFICILE"
    };

    public String[] slide_descrizone = {
            "Descrizione facile...",
            "Descrizione medio...",
            "Descrizone difficile..."
    };

    @Override
    public int getCount() {
        return slide_descrizone.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_facile,container,false);
        ImageView slideImageView = view.findViewById(R.id.imgFacile);
        TextView slideTitolo = view.findViewById(R.id.txtFacile);
        TextView slideDescrizione = view.findViewById(R.id.txtDes1);
        slideImageView.setImageResource(slide_images[position]);
        slideTitolo.setText(slide_titolo[position]);
        slideDescrizione.setText(slide_descrizone[position]);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((ConstraintLayout)object);
    }
}
