package com.example.gioco1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView txtParola;
    private String str="";
    private Boolean giocata1=true;
    private Button btnA, btnB, btnC, btnD, btnE, btnF, btnG, btnH, btnI, btnL, btnM, btnN, btnO, btnP, btnQ, btnR, btnS, btnT, btnU, btnV, btnZ;
    ArrayList<String> array=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        txtParola = findViewById(R.id.txtParola);
        array.add("a");
        array.add("l");
        array.add("f");
        array.add("a");
        txtParola.setText("_ _ _ _");
        btnA = findViewById(R.id.btnA);
        btnB = findViewById(R.id.btnB);
        btnC = findViewById(R.id.btnC);
        btnD = findViewById(R.id.btnD);
        btnE = findViewById(R.id.btnE);
        btnF = findViewById(R.id.btnF);
        btnG = findViewById(R.id.btnG);
        btnH = findViewById(R.id.btnH);
        btnI = findViewById(R.id.btnI);
        btnL = findViewById(R.id.btnL);
        btnM = findViewById(R.id.btnM);
        btnN = findViewById(R.id.btnN);
        btnO = findViewById(R.id.btnO);
        btnP = findViewById(R.id.btnP);
        btnQ = findViewById(R.id.btnQ);
        btnR = findViewById(R.id.btnR);
        btnS = findViewById(R.id.btnS);
        btnT = findViewById(R.id.btnT);
        btnU = findViewById(R.id.btnU);
        btnV = findViewById(R.id.btnV);
        btnZ = findViewById(R.id.btnZ);
        btnA.setOnClickListener(this);
        btnB.setOnClickListener(this);
        btnC.setOnClickListener(this);
        btnD.setOnClickListener(this);
        btnE.setOnClickListener(this);
        btnF.setOnClickListener(this);
        btnG.setOnClickListener(this);
        btnH.setOnClickListener(this);
        btnI.setOnClickListener(this);
        btnL.setOnClickListener(this);
        btnM.setOnClickListener(this);
        btnN.setOnClickListener(this);
        btnO.setOnClickListener(this);
        btnP.setOnClickListener(this);
        btnQ.setOnClickListener(this);
        btnR.setOnClickListener(this);
        btnS.setOnClickListener(this);
        btnT.setOnClickListener(this);
        btnU.setOnClickListener(this);
        btnV.setOnClickListener(this);
        btnZ.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        String parola="alfa";
        switch(v.getId()){
            case R.id.btnA:
                Toast.makeText(getApplicationContext(),"ok",Toast.LENGTH_LONG).show();
                String a = giocata("a",parola,str);
                str=a;
                btnA.setEnabled(false);
                break;
            case R.id.btnB:
                String b = giocata("b",parola,str);
                str=b;
                btnB.setEnabled(false);
                break;
            case R.id.btnC:
                String c = giocata("c",parola,str);
                str=c;
                btnC.setEnabled(false);
                break;
            case R.id.btnD:
                String d = giocata("d",parola,str);
                str=d;
                btnD.setEnabled(false);
                break;
            case R.id.btnE:
                String e = giocata("e",parola,str);
                str=e;
                btnE.setEnabled(false);
                break;
            case R.id.btnF:
                String f = giocata("f",parola,str);
                str=f;
                btnF.setEnabled(false);
                break;
            case R.id.btnG:
                String g = giocata("g",parola,str);
                str=g;
                btnG.setEnabled(false);
                break;
            case R.id.btnH:
                String h = giocata("h",parola,str);
                str=h;
                btnH.setEnabled(false);
                break;
            case R.id.btnI:
                String i = giocata("i",parola,str);
                str=i;
                btnI.setEnabled(false);
                break;
            case R.id.btnL:
                String l = giocata("l",parola,str);
                str=l;
                btnL.setEnabled(false);
                break;
            case R.id.btnM:
                String m = giocata("m",parola,str);
                str=m;
                btnM.setEnabled(false);
                break;
            case R.id.btnN:
                String n = giocata("n",parola,str);
                str=n;
                btnN.setEnabled(false);
                break;
            case R.id.btnO:
                String o = giocata("o",parola,str);
                str=o;
                btnO.setEnabled(false);
                break;
            case R.id.btnP:
                String p = giocata("p",parola,str);
                str=p;
                btnP.setEnabled(false);
                break;
            case R.id.btnQ:
                String q = giocata("q",parola,str);
                str=q;
                btnQ.setEnabled(false);
                break;
            case R.id.btnR:
                String r = giocata("r",parola,str);
                str=r;
                btnR.setEnabled(false);
                break;
            case R.id.btnS:
                String s = giocata("s",parola,str);
                str=s;
                btnS.setEnabled(false);
                break;
            case R.id.btnT:
                String t = giocata("t",parola,str);
                str=t;
                btnT.setEnabled(false);
                break;
            case R.id.btnU:
                String u = giocata("u",parola,str);
                str=u;
                btnU.setEnabled(false);
                break;
            case R.id.btnV:
                String vi = giocata("v",parola,str);
                str=vi;
                btnV.setEnabled(false);
                break;
            case R.id.btnZ:
                String z = giocata("z",parola,str);
                str=z;
                btnZ.setEnabled(false);
                break;
        }
    }

    public String giocata(String lettera, String parola, String str){
        String a = "";
        if(parola.contains(lettera)){
            int posizione = parola.indexOf(lettera);
            a = setParola(lettera, posizione, str);
        }
        return a;
    }

    public String setParola(String lettera, int posizione, String str) {
        if(giocata1){
            int i=1;
            while(i<=posizione){
                str=str+"_ ";
                i++;
            }
            str=str+lettera;
            while(posizione+1<4){
                str=str+" _";
                posizione++;
            }
            giocata1=false;
        }else {
            str = new StringBuilder(str).deleteCharAt(posizione + posizione).toString();
            str = new StringBuilder(str).insert(posizione + posizione, lettera).toString();
        }
        txtParola.setText(str);
        return str;
    }
}
